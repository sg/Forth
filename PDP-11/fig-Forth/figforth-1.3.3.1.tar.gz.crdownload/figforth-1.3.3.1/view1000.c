/*
   Program to mark if content is empty in a 1000 octal byte block,
   to examine DEC disk image files.

   Written by Paul Hardy.

   This program is in the public domain.
*/

#include <stdio.h>
#include <stdlib.h>


int main () {
   int i,j;     /* loop variables */
   int inchar;  /* input character */
   int empty;   /* whether or not a disk block is empty */
   int spaces;  /* whether or not a disk block only has space characters */

   putchar ('\n');
   printf ("         0        1        2        3        4        5        6        7\n");
   printf (" *01000  01234567 01234567 01234567 01234567 01234567 01234567 01234567 01234567");

   i = 0;
   while (!feof (stdin)) {
      if (i != 0 && ((i & 0377777) == 0)) putchar ('\n');
      if ((i & 077777) == 0) printf ("\n%03o %o__ ", i / 01000000, (i / 0100000) & 07);
      empty  = 1;  /* if all NULL characters  */
      spaces = 1;  /* if all space characters */
      for (j = 0; j < 01000 && !feof (stdin); j++) {
         inchar = getchar ();
         if (!feof (stdin) && inchar != '\0')  empty = 0;
         if (!feof (stdin) && inchar != ' ')  spaces = 0;
      }
      if ((i & 07777) == 0) putchar (' ');
      if (!feof (stdin)) {
         if (empty == 1)
            putchar ('.');
         else if (spaces == 1)
            putchar ('_');
         else
            putchar ('+');
         i += 01000;
      }
   }
   printf ("\n\n");

   exit (EXIT_SUCCESS);
}
