/*
   paddat.c - pad FORTH.DAT file so it is 8192 kbytes,
              for RL02 version of FORTH.DAT.
*/

#include <stdio.h>

int main () {
   int i;
   int inchar;

   i = 0;
   do {
      inchar = getchar();
      if (inchar != EOF) putchar (inchar & 0xFF);
      i++;
   } while (i < 8192*1024 && inchar != EOF);
   i--;

   /* Now pad with blanks */
   while (i++ < 8192*1024) putchar (' ');

}
