/*
   crlf.c - make sure lines end with <CR><LF>, not just <LF>.
   This is to help in moving GNU/Linux or other Unix-like files
   to DEC PDP-11 operating systems.

   Author: Paul Hardy

   This work is in the public domain.

   Synopsis: crlf < input-file > output-file
*/

#include <stdio.h>
#include <stdlib.h>


int main () {
   int inchar; /* input character */

   while (!feof (stdin)) {
      inchar = getchar ();
      /*
         Ignore all '\r', but when we read '\n' print "\r\n".
      */
      if (!feof (stdin) && inchar != '\r') {
         if (inchar == '\n') printf ("\r\n");
         else putchar (inchar & 0xFF);
      }
   }

   exit (EXIT_SUCCESS);
}
