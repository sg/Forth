/*
   dat2txt - convert FORTH.DAT screens to 64 character lines,
   ending with linefeed.  The txt2dat program performs a
   conversion in the opposite direction.

   Author: Paul Hardy

   This program is in the public domain.
*/

#include <stdio.h>
#include <stdlib.h>


int main () {
   int i;       /* loop variable   */
   int tempch;  /* input character */
   
   i = 0;
   do {
      if ((i & 0x3FF) == 0) printf ("\nSCREEN # %d\n", (i >> 10) + 1);
      if ((i & 0x3F) == 0) printf ("%3d ", (i & 0x3FF) >> 6);
      tempch = getchar ();
      if (!feof (stdin)) {
         putchar (tempch & 0xFF);
      }
      if ((++i & 0x3F) == 0) putchar ('\n');
   }  while (!feof (stdin));

   exit (EXIT_SUCCESS);
}
