/*
   rad50.c - convert RADIX 50 to ASCII and ASCII to RADIX 50

   Written by Paul Hardy.

   This file is in the public domain.

   There are two functions for converting RADIX-50 to/from ASCII:

      rad50_ascii - Convert RADIX-50 string of 3 characters to ASCII string.

      ascii_rad50 - Convert 3 ASCII characters in a string to a RADIX 50 word.
*/

#include <stdlib.h>
#include <ctype.h>

/*
   Convert RADIX-50 string of 3 characters to ASCII string.
*/
void rad50_ascii (uint16_t rad50, char *astring) {
   char asciified[4]; /* return string */
   char ascii1, ascii2, ascii3;  /* ASCII translation */

   char rad50ascii [40] = {' ','A','B','C','D','E','F','G',
                           'H','I','J','K','L','M','N','O',
                           'P','Q','R','S','T','U','V','W',
                           'X','Y','Z','$','.','?','0','1',
                           '2','3','4','5','6','7','8','9'};

   ascii3 = rad50ascii [rad50 % 050];
   rad50 /= 050;
   ascii2 = rad50ascii [rad50 % 050];
   rad50 /= 050;
   ascii1 = rad50ascii [rad50 % 050];
   astring[0] = asciified[0] = ascii1;
   astring[1] = asciified[1] = ascii2;
   astring[2] = asciified[2] = ascii3;
   astring[3] = asciified[3] = '\0';

   return;
}


/*
   Convert 3 ASCII characters in a string to a RADIX 50 word.
*/
void ascii_rad50 (char *ascii_in, uint16_t *rad50_out) {
   int      i;         /* loop variable */
   uint16_t rad50;     /* return value  */
   int      thischar;   /* ASCII character being converted */
   int      thisrad50;  /* RADIX 50 conversion of current character */

   int toupper (int);   /* convert lower case letter to upper case */

   rad50 = 000000;

   for (i = 0; i < 3; i++) {
      rad50 *= 050; /* shift last character one place to the left */
      thischar  = ascii_in[i];
      thisrad50 = 000;
      switch (thischar) {
         case '$': thisrad50 = 033; break;
         case '.': thisrad50 = 034; break;
         case '?': thisrad50 = 035; break;
         default:
            /* Convert if a digit */
            if ((thischar >= '0') && (thischar <= '9')) {
               thisrad50 = thischar - '0' + 036;
            }
            /* Convert if a letter */
            else {
               thischar = toupper (thischar);
               if ((thischar >= 'A') && (thischar <= 'Z')) {
                  thisrad50 = thischar - 'A' + 001;
               }
            }
            /* Otherwise, the RADIX 50 value is encoded as 0 */
            break;
      }
      rad50 += thisrad50;
   }

   *rad50_out = rad50;
   return;
}

