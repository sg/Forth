/*
   rt11format.c - Create an RL02 hard disk image with RT-11 file system.

   Author: Paul Hardy

   This work is in the public domain.  No warranty is expressed or implied.

   Call with list of files to place in RT-11 file system.
   Call with "-b" flag to create blank disk with no files.
   Call with no parameters to create RT-11 file system with
        FORTH.DAT, FORTH.MAC, and BOOTRL.MAC.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rt11format.h"

#define MAXFILES   20  /* maximum number of files to initialize on disk */

/*
   Valid RT-11 filenames can be given on the command line.
   If they are not, default file names "FORTH.DAT", "FORTH.MAC",
   and "BOOTRL.MAC" are used to build the FIG Forth RL02 disk image.
*/

int main (int argc, char *argv[]) {
   int      i, j;     /* loop variables */
   struct   GENERIC_DISK disk;
   struct   HOME_BLOCK   home_block;
   struct   RT11_DIR_HEAD rt11_header;
   int      blank=0;          /* Create a non-blank FIG Forth disk by default */
   char     filenames[MAXFILES][12]; /* added during directory initialization */
   FILE    *imagefp=stdout;          /* file pointer to output disk file      */
   /*
      If serno0 or serno1 are non-zero, this pair will be used
      for a custom disk serial number.  The number is two 16-bit
      unsigned numbers.
   */
   unsigned serno0=0, serno1=0;   /* for non-default serial numbers */

   void print_help       (char *progname);  /* print help message            */

   void init_params      (int    blank,     /* non-zero for blank disk       */
                          unsigned serno0,  /* custom non-zero serial number */
                          unsigned serno1,  /* custom non-zero serial number */
                          struct GENERIC_DISK  *,
                          struct HOME_BLOCK    *,
                          struct RT11_DIR_HEAD *,
                          char   filenames[MAXFILES][12]);

   void factory_init     (struct GENERIC_DISK  *);
   void write_home_block (struct GENERIC_DISK  *, struct HOME_BLOCK *);
   void rt11_create      (struct GENERIC_DISK  *,
                          struct HOME_BLOCK    *,
                          struct RT11_DIR_HEAD *,
                          char   filenames[MAXFILES][12]);

   void *calloc       (size_t count, size_t size);
   int   fputc        (int, FILE *);

   /*
      Use default file names if none specified on command line.
   */
   if (argc <= 1) {
      strcpy (filenames[0], "FORTH.DAT");
      strcpy (filenames[1], "FORTH.MAC");
      strcpy (filenames[2], "BOOTRL.MAC");
      filenames[3][0] = '\0';  /* null last entry flags end */
   }
   else {
      /* First, process options.  File names for disk storage then follow. */
      for (i = 1; i < argc && argv[i][0] == '-'; i++) {
         switch (argv[i][1]) {
            case 'b': /* Create a blank disk */
                      /* Don't load any files into directory. */
                      filenames[0][0] = '\0';
                      /* Write a blank Owner ID and Volume ID on home block */
                      blank = 1;
                      break;
            case 'o': /* Output filename */
                      /*
                         If image file specified, try using it;
                         otherwise, ignore the "-o" flag.
                      */
                      if (argv[i][2] != '\0') {
                         if ((imagefp = fopen (&argv[i][2], "w")) == NULL) {
                            fprintf (stderr,
                                     "ERROR: can't open %s for output\n",
                                     &argv[i][2]);
                            exit (EXIT_FAILURE);
                         }
                      }
                      break;
            case 's': /* Serial number */
                      sscanf (&argv[i][2], "%o.%o", &serno0, &serno1);
                      break;
            case 'h': /* Help message */
            default:
                      print_help (argv[0]);
                      exit (EXIT_SUCCESS);
                      break;
         }
      }
      if (i < argc) {
         for (j = 0; i < argc; i++, j++) {
            strcpy (filenames[j], argv[i]);
         }
         filenames[j][0] = '\0';
      }
   }

   /* Get configurable parameters  */
   init_params (blank, serno0, serno1,
                &disk, &home_block, &rt11_header, filenames);

   /* Initialize home block image to all zeroes */
   home_block.image = calloc (01000, sizeof (uint8_t));

   /* Initialize disk to all zeroes */
   disk.image = calloc (disk.disk_bytes, sizeof (uint8_t));

   /* Add disk serial number and bad sector map to disk */
   factory_init (&disk);

   /* Write boot code that just outputs that there is no boot loader */
   for (i = j = 0; i < BOOTWORDS; i++) {
      disk.image[j++] = LOW  (noboot[i]);
      disk.image[j++] = HIGH (noboot[i]);
   }

   /* Create RT-11 directory structure */
   rt11_create (&disk, &home_block, &rt11_header, filenames);

   /* Add DEC Block 1, starting at octal byte 1000 */
   write_home_block (&disk, &home_block);

   /* Done creating the disk image -- now write it out */
   for (i = 0; i < disk.disk_bytes; i++) (void)fputc (disk.image[i], imagefp);

   exit (EXIT_SUCCESS);
}


/*
   Print help message.  This is passed argv[0], to print the
   calling program's name.
*/
void print_help (char *progname) {

   fprintf (stderr, "\nSyntax:\n\n");
   fprintf (stderr, "   %s [-b] [-h] [-oimage] [-s] [files...]\n\n", progname);
   fprintf (stderr, "      -b       Create blank RT-11 disk\n\n");
   fprintf (stderr, "      -h       This help output\n\n");
   fprintf (stderr, "      -oimage  Output RL02 image to file \"image\".\n");
   fprintf (stderr, "               If absent, image is written to stdout.\n");
   fprintf (stderr, "               Normal informational output is written\n");
   fprintf (stderr, "               to stderr so as not to conflict with\n");
   fprintf (stderr, "               disk image output on stdout.\n\n");
   fprintf (stderr, "      -sn1.n2  Serial number:\n");
   fprintf (stderr, "               n1 and n2 are 16-bit octal unsigned\n\n");
   fprintf (stderr, "      files...  One or more RT-11 files to add\n\n");

   fprintf (stderr, "   If no files are specified, and the disk is not\n");
   fprintf (stderr, "   blank (\"-b\"), three default minimal FIG Forth\n");
   fprintf (stderr, "   files will be placed on the disk: FORTH.DAT,\n");
   fprintf (stderr, "   FORTH.MAC, and BOOTRL.MAC (the RL02 boot loader\n");
   fprintf (stderr, "   that bootstraps standalone FIG Forth).\n\n");

   return;
}


/*
   Initialize parameters.  In the future, these could be set
   from a configuration file or from user prompts.
*/
void init_params (int      blank,
                  unsigned serno0,
                  unsigned serno1,
                  struct   GENERIC_DISK  *disk,
                  struct   HOME_BLOCK    *home_block,
                  struct   RT11_DIR_HEAD *rt11_header,
                  char     filenames[MAXFILES][12]) {

   /*
      RL02 disk parameters.
   */
   disk->cylinders  = RL02_CYLINDERS;
   disk->heads      = RL02_HEADS;
   disk->sectors    = RL02_SECTORS;
   disk->sec_bytes  = RL02_SEC_BYTES;
   disk->interleave = RL02_INTERLEAVE;
   disk->skew       = RL02_SKEW;

   /* Bytes on last track, for bad sector map */
   disk->track_bytes = disk->sectors * disk->sec_bytes;

   /* Total bytes on disk. */
   disk->disk_bytes  = disk->cylinders * disk->heads * disk->track_bytes;

   /* Default disk serial number; can be changed for each disk. */
   if (serno0 != 000000 || serno1 != 000000) {
      disk->serno0 = serno0;
      disk->serno1 = serno1;
   }
   else {
      disk->serno0 = RL02_SERNO0; /* Serial Number, high word */
      disk->serno1 = RL02_SERNO1; /* Serial Number, low  word */
   }

   /*
      RT-11 Home Block parameters, starting at disk location 1000 octal.
   */
   home_block->cluster_size          = HOME_CLUSTER_SIZE;
   home_block->first_directory_seg   = HOME_FIRST_DIRECTORY_SEG;
   strcpy (home_block->system_version, HOME_SYSTEM_VERSION);
   if (blank == 0) {  /* Don't put FIG Forth labeling on a blank disk */
      strcpy (home_block->volume_id,   HOME_VOLUME_ID     );
      strcpy (home_block->owner_name,  HOME_OWNER_NAME    );
   }
   strcpy (home_block->system_id,      HOME_SYSTEM_ID     );

   return;
};


/*
   Initialize disk as a factory-fresh blank disk with no bad sectors.
*/
void factory_init (struct GENERIC_DISK *disk) {

   int i, j;  /* loop variables */
   int start_bad;  /* start of last track, with bad sector map */

   start_bad = disk->disk_bytes - disk->track_bytes;
   /*
      Bad sector map is in each sector of last track on disk.
      The map ends with a sector value of -1, so write -1 on
      all bytes in sector to initialize.
   */
   memset (&disk->image[start_bad], 0xFF, disk->track_bytes);
   /*
      Plug in 32-bit serial number and 32 bit reserved field of zeroes.
   */
   i = start_bad;
   do {
      j = i;
      /* PDP-11s are little endian, so write low byte then high byte */
      disk->image[j++] = LOW  (disk->serno0);
      disk->image[j++] = HIGH (disk->serno0);
      disk->image[j++] = LOW  (disk->serno1);
      disk->image[j++] = HIGH (disk->serno1);
      disk->image[j++] =  000;
      disk->image[j++] =  000;
      disk->image[j++] =  000;
      disk->image[j++] =  000;
      i += 0400;
   }  while (i < disk->disk_bytes);
   
   return;
}


/*
   Write a Home Block onto the disk image.  This carries information
   about the operating system that initialized the disk.  Write
   information that RT11 version 4 would write.
*/
void write_home_block (struct GENERIC_DISK *disk,
                       struct HOME_BLOCK   *home_block) {

   int i;               /* loop variable         */
   uint16_t rad50word;  /* RADIX-50 encoded word */
   uint16_t sum16;      /* Files-11 checksum     */

   void ascii_rad50 (char *, uint16_t *);

   /* Make sure ASCII strings are null-terminated */
   home_block->system_version [ 3] = '\0';
   home_block->volume_id      [12] = '\0';
   home_block->owner_name     [12] = '\0';
   home_block->system_id      [12] = '\0';

   home_block->image [0722] = LOW  (home_block->cluster_size);
   home_block->image [0723] = HIGH (home_block->cluster_size);
   home_block->image [0724] = LOW  (home_block->first_directory_seg);
   home_block->image [0725] = HIGH (home_block->first_directory_seg);
   ascii_rad50 (home_block->system_version, &rad50word);
   home_block->image [0726] = LOW  (rad50word);
   home_block->image [0727] = HIGH (rad50word);
   (void)strcpy ((char *)&home_block->image[0730], home_block->volume_id);
   (void)strcpy ((char *)&home_block->image[0744], home_block->owner_name);
   (void)strcpy ((char *)&home_block->image[0760], home_block->system_id);
   /* Convert any nulls to spaces in ASCII string fields */
   for (i = 0730; i < (0730 + 36); i++) {
      if (home_block->image[i] == '\0') home_block->image[i] = ' ';
   }

   /*
      Compute checksum for home block.
   */
   sum16 = 0;
   for (i = 0000; i < 0776; i += 2) {
      sum16 +=  (uint16_t)home_block->image [i] |
               ((uint16_t)home_block->image [i+1] << 8);
   }
   home_block->sum16 = sum16;
   home_block->image [0776] = LOW   (sum16);
   home_block->image [01777] = HIGH (sum16);

   /* Copy the home block image to the disk image */
   for (i = 0; i < 01000; i++) {
      disk->image[i + 01000] = home_block->image[i];
   }

   return;
}


/*
   Create empty RT-11 directory structure
*/
void rt11_create (struct GENERIC_DISK  *disk,
                  struct HOME_BLOCK    *home_block,
                  struct RT11_DIR_HEAD *rt11_header,
                  char   filenames[MAXFILES][12]) {

   int      i,j;         /* loop variable                            */
   int      fnum;        /* file number in list of files             */
   int      addr;        /* general purpose disk address             */
   int      file_addr;   /* disk address of current file             */
   int      entry_addr;  /* disk address of current directory entry  */
   uint16_t tempword;    /* holding place for RADIX-50 resutls, etc. */
   int      fbytes;      /* number of bytes in file                  */
   int      fblocks;     /* number of 512-byte blocks in file        */
   int      nfiles;      /* number of permanent files in directory   */
   int      freeblocks;  /* number of free 512-byte blocks on disk   */
   int      blocksused;  /* number of 512-byte blocks with files     */
   FILE     *infp;       /* input file pointer                       */
   uint8_t   inchar;     /* one character from input file            */
   char      rtfile[12]; /* RT-11 formatted filename for printing    */
   /* Default creation date is the release date of FIG Forth 1.3 */
   uint16_t cdate = (1 << 10) | (21 << 5) | (1980 - 1972); /* 21-Jan-1980 */

   struct RT11_DIR_ENTRY rt11entry; /* RT-11 directory file entries */

   void fname2radix50 (char *, struct RT11_DIR_ENTRY *);


   /*
      Calculate number of 512-byte (01000 byte octal) blocks on disk
      for files.  Subtract the first 016000 (octal) bytes for directory
      entries, etc., and subtract the last track for bad sector data.

      The address 016000 octal is fixed as the starting point for
      FORTH.DAT, because the binary loadable Forth image must start
      at FORTH.DAT Screen 40 at a known sector on the disk in order
      for the boot sector loader to load the binary image correctly.
      That is also why the RT-11 directory has 4 directory segments,
      so the FORTH.DAT file will start at 016000.  If it were not for
      that constraint, this section could be generalized for a variable
      number of directory segments, with the first file starting right
      the last directory segment.
   */
   freeblocks = (disk->disk_bytes - (016000 + disk->track_bytes)) / 01000;
   blocksused = 0;  /* No files placed on disk yet */
   nfiles     = 0;  /* No files placed on disk yet */

   /*
      Fill in RT-11 directory header structure.
   */
   rt11_header->nsegs            = RT11_NSEGS;
   rt11_header->next_dir_seg     = 0;  /* no next segment in use */
   rt11_header->highest_seg_used = 1;
   rt11_header->info_bits        = RT11_INFO_BITS;
   rt11_header->first_file_block = RT11_FIRST_FILE_BLK;

   /* Start address of RT-11 directory structure on disk */
   addr = home_block->first_directory_seg * 01000;

   /* Number of directory segments on disk */
   disk->image[addr++] = LOW  (rt11_header->nsegs);
   disk->image[addr++] = HIGH (rt11_header->nsegs);

   /* No next directory segment is in use */
   disk->image[addr++] = LOW  (rt11_header->next_dir_seg);
   disk->image[addr++] = HIGH (rt11_header->next_dir_seg);

   /* This is currently the highest directory segment in use */
   disk->image[addr++] = LOW  (1);
   disk->image[addr++] = HIGH (1);  /* always 0 */

   /* Number of information bits (default is 0) */
   disk->image[addr++] = LOW  (rt11_header->info_bits);
   disk->image[addr++] = HIGH (rt11_header->info_bits);

   /* First file starting block */
   disk->image[addr++] = LOW  (rt11_header->first_file_block);
   disk->image[addr++] = HIGH (rt11_header->first_file_block);

   /* Start of directory entries on disk, which is right after header */
   entry_addr = addr;

   /* Start of first file on disk must be 16,000 octal for FIG Forth disk */
   file_addr = 016000;

   /* Create individual file directory entries */
   fprintf (stderr, "\nCreating RT-11 Directory:\n\n");
   for (fnum = 0; fnum < MAXFILES && filenames[fnum][0] != '\0'; fnum++) {

      strncpy (rtfile, filenames[fnum], 10);
      rtfile[10] = '\0';
      for (j = 0; j < 6 && rtfile[j] != '.'; j++); /* find extension */
      rtfile[j] = '\0';      /* turn '.' to null                     */
      rtfile[j+4] = '\0';    /* limit file extension to 3 characters */
      fprintf (stderr, "   %-6s.%-3s ", rtfile, &rtfile[j+1]);
      rt11entry.status = 02000;  /* permanent file */
      rt11entry.job_channel   = 0;
      rt11entry.creation_date = cdate;

      fname2radix50 (filenames[fnum], &rt11entry); /* Radix-50 conversion */

      /*
         Add this file to the disk image and calculate file size.
      */
      if ((infp = fopen (filenames[fnum], "r")) == NULL) {
         fprintf (stderr, "\nERROR: cannot open %s\n\n", filenames[fnum]);
         exit (EXIT_FAILURE);
      }
      fseek (infp, 0L, SEEK_END);
      /* Determine number of bytes in file */
      fbytes  = ftell (infp);
      /* Determine number of blocks in file for RT-11 directory entry */
      fblocks = (fbytes + 0777) / 01000;
      fprintf (stderr, "%6d blocks\n", fblocks);
      /* Copy the file to disk image */
      rewind (infp);
      for (j = 0; j < fbytes; j++) {
         inchar = fgetc (infp) & 0xFF;
         disk->image [file_addr++] = inchar;
      }
      (void)fclose (infp);
      /* Pad last block of file with NULL characters if necessary */
      while ((j & 0777) != 0) {
         disk->image [file_addr++] = '\0';
         j++;
      }
      rt11entry.nblocks = fblocks;

      /* Copy directory entry information into disk image */
      disk->image [entry_addr++] = LOW  (rt11entry.status);
      disk->image [entry_addr++] = HIGH (rt11entry.status);
      disk->image [entry_addr++] = LOW  (rt11entry.fname1);
      disk->image [entry_addr++] = HIGH (rt11entry.fname1);
      disk->image [entry_addr++] = LOW  (rt11entry.fname2);
      disk->image [entry_addr++] = HIGH (rt11entry.fname2);
      disk->image [entry_addr++] = LOW  (rt11entry.fext);
      disk->image [entry_addr++] = HIGH (rt11entry.fext);
      disk->image [entry_addr++] = LOW  (rt11entry.nblocks);
      disk->image [entry_addr++] = HIGH (rt11entry.nblocks);
      disk->image [entry_addr++] = LOW  (rt11entry.job_channel);
      disk->image [entry_addr++] = HIGH (rt11entry.job_channel);
      disk->image [entry_addr++] = LOW  (rt11entry.creation_date);
      disk->image [entry_addr++] = HIGH (rt11entry.creation_date);

      nfiles++;               /* Number of permanent files      */
      blocksused += fblocks;  /* Blocks size of permanent files */
      freeblocks -= fblocks;  /* Free blocks remaining on disk  */
   }

   /*
      Now write final directory entries to finish directory.
   */
   rt11entry.status = 01000;
   rt11entry.fname1 = rt11entry.fname2 = rt11entry.fext = 0;
   rt11entry.nblocks       = freeblocks;
   rt11entry.job_channel   = 0;
   rt11entry.creation_date = 0;

   fname2radix50 (" EMPTY.FIL", &rt11entry); /* Radix-50 conversion */

   /* Copy directory entry information into disk image */
   disk->image [entry_addr++] = LOW  (rt11entry.status);
   disk->image [entry_addr++] = HIGH (rt11entry.status);
   disk->image [entry_addr++] = LOW  (rt11entry.fname1);
   disk->image [entry_addr++] = HIGH (rt11entry.fname1);
   disk->image [entry_addr++] = LOW  (rt11entry.fname2);
   disk->image [entry_addr++] = HIGH (rt11entry.fname2);
   disk->image [entry_addr++] = LOW  (rt11entry.fext);
   disk->image [entry_addr++] = HIGH (rt11entry.fext);
   disk->image [entry_addr++] = LOW  (rt11entry.nblocks);
   disk->image [entry_addr++] = HIGH (rt11entry.nblocks);
   disk->image [entry_addr++] = LOW  (rt11entry.job_channel);
   disk->image [entry_addr++] = HIGH (rt11entry.job_channel);
   disk->image [entry_addr++] = LOW  (rt11entry.creation_date);
   disk->image [entry_addr++] = HIGH (rt11entry.creation_date);

   /* Mark the end of this directory segment. */
   disk->image [entry_addr++] = LOW  (04000);
   disk->image [entry_addr++] = HIGH (04000);

   fprintf (stderr, "\n   %4d Files, %5d Blocks Used\n", nfiles, blocksused);
   fprintf (stderr, "\n   %d Free Blocks\n\n", freeblocks);

   /*
      Make a recovery directory copy in the Home Block
      area reserved for "INITIALIZE/RESTORE data area",
      bytes 204(octal) through 251(octal).  This is taken
      from the beginning of the RT-11 directory in the
      first directory segment.
   */
   addr = home_block->first_directory_seg * 01000;
   for (i = 0204; i < 0252; i++) {
      home_block->image[i] = disk->image[addr++];
   }

   return;
}


/*
   Add a file, specified as filename, to a newly created RT-11 directory.
*/
int rt11entry (uint8_t *disk,
                char *filename,
                struct RT11_DIR_ENTRY *rt11entry) {

   int      i, j;  /* loop variables */
   int      addr;  /* byte location in disk image */
   uint8_t  outch1, outch2;  /* 2 bytes for little-endian output */
   uint8_t  outword;         /* 2-byte PDP-11 word */
   char     cfname1[4], cfname2[4], cfext[4]; /* for ASCII to Radix-50 */
   uint16_t fname1, fname2, fext; /* Radix-50 file name and extension */

   int       retval; /* return value; 0 if okay, -1 if error */

   retval = 0;

   /* If status is 02000, try to open the file on disk. */

   /* Determine file size in bytes */

   /* Copy file to disk */

   /* Pad end of last block with nulls if necessary */

   /* Update directory entry information */
   
   return retval;
}


/*
   Convert an ASCII file name to its Radix-50 equivalent, populating
   entries in the rt11entry struct.
*/
void fname2radix50 (char *filename, struct RT11_DIR_ENTRY *rt11entry) {
   int i, j;       /* loop variables */
   int dotloc;     /* location of '.' in filename */
   char fpart[12]; /* part of a filename, for Radix-50 conversion */

   void ascii_rad50 (char *, uint16_t *);

   /* Copy file name to temporary buffer */
   strncpy (fpart, filename, 10);
   fpart[10] = '\0';

   /*
      Find the dot and copy the file extension part first.
   */
   for (i = 0; fpart[i] != '.' && i < 6; i++);
   dotloc = i;
   fpart[dotloc] = '\0';
   fpart[dotloc + 4] = '\0'; /* null terminate end of file extension */
   strncpy (fpart, &fpart[dotloc + 1], 4);
   /* Pad with spaces for Radix-50 */
   for (j = 0; j < 4; j++) if (fpart[j] == '\0') fpart[j] = ' ';
   ascii_rad50 (fpart, &rt11entry->fext);

   /*
      Now convert the beginning part of the file name.
   */
   strncpy (fpart, filename, 6);
   fpart[6] = '\0';
   for (i = 0; i < 6; i++) {
      if (fpart[i] == '\0' || fpart[i] == '.') fpart[i] = ' ';
   }
   ascii_rad50 (fpart, &rt11entry->fname1);
   ascii_rad50 (&fpart[3], &rt11entry->fname2);

   return;
}


