/*
   diskpatch - insert a binary file into a disk file

   Author: Paul Hardy

   This program is in the public domain.

   Synopsis: diskpatch <diskfile> <octal-start-byte> <patch-file>
*/

#include <stdio.h>
#include <stdlib.h>


int main (int argc, char *argv[]) {
   int   i;          /* loop variable */
   long  start_byte; /* starting location to patch disk file */
   int   tempch;     /* temporary character being transferred */

   FILE *diskfp;     /* disk file pointer */
   FILE *patchfp;    /* patch file pointer */

   int   atoi   (const char *);
   FILE *fopen  (const char *, const char *);
   int   fclose (FILE *);

   if (argc != 4) {
      fprintf (stderr,
               "\nSyntax: %s <diskfile> <octal-start-byte> <patch-file>\n",
               argv[0]);
      exit (EXIT_FAILURE);
   }

   if ((diskfp = fopen (argv[1], "r+")) == NULL) {
      fprintf (stderr, "ERROR: cannot access disk file %s\n\n", argv[1]);
      exit (EXIT_FAILURE);
   }

   /* start_byte = atoi (argv[2]); */
   start_byte = 0;
   for (i = 0; argv[2][i] >= '0' && argv[2][i] <= '7'; i++) {
      start_byte <<= 3;
      start_byte  |= argv[2][i] & 7;
   }
   fprintf (stderr, "Starting at octal byte %06lo\n", start_byte);

   if ((patchfp = fopen (argv[3], "r")) == NULL) {
      fprintf (stderr, "ERROR: cannot access patch file %s\n\n", argv[1]);
      exit (EXIT_FAILURE);
   }

   fseek (diskfp, start_byte, SEEK_SET);

   do {
      tempch = fgetc (patchfp) & 0xFF;
      if (!feof (patchfp)) {
         fputc (tempch, diskfp);
      }
   }  while (!feof (patchfp));

   fclose (patchfp);
   fclose (diskfp);

   exit (EXIT_SUCCESS);
}
