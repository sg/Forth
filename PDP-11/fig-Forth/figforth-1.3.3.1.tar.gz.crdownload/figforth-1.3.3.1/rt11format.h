/*
   rt11format.h - Header file for rt11format.c.

   Author: Paul Hardy

   This work is in the public domain.  No warranty is expressed or implied.
*/

/* Macros for high and low byte in a word */
#define LOW(X)  ( X       & 0xFF)
#define HIGH(X) ((X >> 8) & 0xFF)

/*
   Defines for RL02 disk cartridge.
*/
#define RL02_CYLINDERS	512
#define RL02_HEADS	  2
#define RL02_SECTORS     40
#define RL02_SEC_BYTES  256
#define RL02_INTERLEAVE	  0
#define RL02_SKEW	  0
/* Default serial number values; can be changed for each disk */
#define RL02_SERNO0	012345
#define RL02_SERNO1	054321

/*
   Defines for standard RT-11 Disk Home Block, including volume labels.
*/
/*
   HOME_CLUSTER_SIZE is the cluster size to use when allocating space
   for disk files.  It is the number of blocks to increment at a time,
   and must be a power of 2 between 1 and 256, inclusive.  The default
   is to allocate file space in one block increments.
*/
#define HOME_CLUSTER_SIZE	 1	   /* Standard RT-11 value           */
#define HOME_FIRST_DIRECTORY_SEG 6	   /* Standard RT-11 value           */
#define HOME_SYSTEM_VERSION	"V3A"      /* RT-11 Version -- Do Not Change */
#define HOME_SYSTEM_ID		"DECRT11A" /* RT-11 Version -- Do Not Change */
/* The next 2 defines are for the disk volume label and can be customized    */
#define HOME_OWNER_NAME		"F.I.G."
#define HOME_VOLUME_ID		"FORTH-1.3.3 "

/*
   Defines for RT-11 directory structure.
*/
#define RT11_INFO_BITS         0  /* No information bits in entries          */
#define RT11_NSEGS	       4  /* Number of directory segments            */
/* First file with these parameters starts at block 16 octal */
#define RT11_FIRST_FILE_BLK	  (HOME_FIRST_DIRECTORY_SEG + (RT11_NSEGS * 2))
#define RT11_DEFAULT_DATE 003250  /* 21-Jan-1980: FIG Forth 1.3 release date */

/*
   Values for the status field in an RT-11 directory entry.
*/
#define RT11_STATUS_TENTATIVE	000400
#define RT11_STATUS_EMPTY	001000
#define RT11_STATUS_PERMANENT	002000
#define RT11_STATUS_EOS		004000
#define RT11_STATUS_EREAD       040000
#define RT11_STATUS_EPROT       100000
/* EPRE is the Prefix Block Indicator bit */
#define RT11_STATUS_EPRE        000020


/*
   NOBOOT.BIN values -- a boot sector that just outputs that there
   is no boot sector on the disk, and then halts.  This will be the
   boot sector if it is not replaced by another piece of code.
*/
#define BOOTWORDS 0100
uint16_t noboot[BOOTWORDS] = {
   0000240,0004067,0000044,0000015,0000000,0005000,0047077,0020117,/* 000 */
   0047502,0052117,0046040,0040517,0042504,0020122,0047117,0042040,/* 020 */
   0051511,0006513,0000000,0000000,0100012,0105737,0177564,0100375,/* 040 */
   0112037,0177566,0100372,0000000,0000000,0000000,0000000,0000000,/* 060 */
};


/*
   Notes on disk structure in general.

   Information from DEC's "RT-11 Volume and File Formats Manual",
   Order Number AA-PD6PA-TC, August 1991 pertaining to RT-11 version 5.6:

       Octal     Usage Example with
      Block(s)  4 Directory Segments
      --------  --------------------
           00   Reserved
           01   Home Block
      02 - 05   Reserved
      06 - 07   Directory Segment 1
      10 - 11   Directory Segment 2
      12 - 13   Directory Segment 3
      14 - 15   Directory Segment 4
      16 -      Files

      
*/


/*
   Characteristics of a particular disk.
*/
struct GENERIC_DISK {
   uint8_t *image;        /* disk byte image */
   int      cylinders ;   /* cylinders/disk  */
   int      heads     ;   /* heads/cylinder  */
   int      sectors   ;   /* sectors/track   */
   int      sec_bytes ;   /* bytes/sector    */
   int      disk_bytes;   /* bytes/disk      */
   /* the next two fields are for disks that require them (floppy disks)   */
   int      interleave;   /* sectors to skip across on same track          */
   int      skew;         /* sectors to skip moving one track to the next  */
   /* track_bytes is used to reserve the last track for the bad sector map */
   int      track_bytes;  /* bytes/track     */
   uint16_t serno0;       /* Serial Number, high word */
   uint16_t serno1;       /* Serial Number, low  word */
};

/*
   Digital Equipment Corporation disk Volume Identification Block
   (Home Block) structure, starting at logical disk byte 01000 (octal).
   This block must contain at least 256 words (512 decimal bytes).

   Information from DEC Standard 167, Rev. A, "Volume Identification
   for Removable Disk Pack Systems", May 1977:

       Block 1
      Word Range  Usage
       (Octal)
      ----------  -----
      000 - 353   Software system-specific
      354 - 361   12(decimal) character ASCII pack identity
      362 - 367   12(decimal) character ASCII pack owner name
      370 - 375   12(decimal) character ASCII format; examples:
                  "TOPS-10" "TOPS-20" "FILES11" "RT-11" "DOS-11" "RSTS"
                  "SCRATCH".  The exact name depends on the file system
                  that creates the disk.
      376 - 377   Software system-specific
      400 - 777   Not defined in DEC Standard 167

   Information from DEC's "RT-11 Volume and File Formats Manual",
   Order Number AA-PD6PA-TC, August 1991 pertaining to RT-11 version 5.6:

      Blocks 0 through 5 are reserved for system use; directory begins at
      Block 6.

       Block 1
      Word Range  Usage
       (Octal)
      ----------  -----
      000 - 201   Bad block replacement table
      202 - 203   ???
      204 - 251   INITIALIZE/RESTORE data area
      252 - 273   BUP information area;
                  if BUP volume, this is "BUQ" and 9 spaces, with
                  binary volume number in byte 266 octal
      274 - 677   ???
      700 - 703   Reserved; zeroes
      722 - 723   Pack Cluster Size (default = 1)
      724 - 725   Block number of first directory segment (default = 1)
      726 - 727   System version in Radix-50 (default = "V3A")
      730 - 743   Volume Identification (default = "RT11" and 7 spaces)
      744 - 757   Owner Name (default = 12(decimal) spaces)
      760 - 773   System Identification (default = "DECRT11A" and 4 spaces)
      774 - 775   ???
      776 - 777   Checksum: sum of all preceding words in Block 1
*/
struct HOME_BLOCK {
   /*
      The image field is intended to hold a raw image of the 01000 octal
      bytes in a Home Block.  It is not currently used but is present
      for future use for filling in more words in the Home Block.
   */
   uint8_t *image;
   uint16_t cluster_size;        /* OS dependent                     */
   uint16_t first_directory_seg; /* OS dependent                     */
   char system_version  [4];     /* OS version that formatted disk   */
   char volume_id      [13];     /* Part of disk volume label        */
   char owner_name     [13];     /* Part of disk volume label        */
   char system_id      [13];     /* OS ID that formatted disk        */
   uint16_t sum16;               /* checksum for Home Block          */
};


/*
   Defines for RT-11 directory structure.

   Information from DEC's "RT-11 Volume and File Formats Manual",
   Order Number AA-PD6PA-TC, August 1991 pertaining to RT-11 version 5.6:

      Each directory segment is 512(decimal) / 1000(octal) words long.
      A directory can have from 1 to 31(decimal) segments.
      Each segment has the format:

        5-Word Header:
           Word 1: Total number of segments in this directory, 1-31(decimal)
           Word 2: Segment number of next logical directory segment (0 for end)
           Word 3: Number of highest segment currently in use (only maintained
                   in first segment)
           Word 4: Number of extra bytes per directory entry (always an even
                   unsigned octal number)
           Word 5: Block number on volume where stored data identified by
                   this segment begins
        Directory Entries
        End-of-segment Marker: word containing 004000 (octal)
*/
struct RT11_DIR_HEAD {
   uint16_t nsegs;             /* number of directory segments on disk     */
   uint16_t next_dir_seg;      /* next directory segment in use; 0 if none */
   uint16_t highest_seg_used;  /* highest directory segment in use         */
   uint16_t info_bits;         /* information bits per file                */
   uint16_t first_file_block;  /* disk block of start of first file        */
};


/*
   RT-11 directory entry for a file.

   Information from DEC's "RT-11 Volume and File Formats Manual",
   Order Number AA-PD6PA-TC, August 1991 pertaining to RT-11 version 5.6:

      Word  Usage
      ----  -----
        1   Status
        2   File Name, characters 1-3 in Radix-50 format
        3   File Name, characters 4-6 in Radix-50 format
        4   File Type, characters 1-3 in Radix-50 format
        5   Total File Length
        6   Job # byte | Channel # byte
        7   Creation Date
       >7   Optional Extra Words

      status is the status of the file:

                   File
                 Type|Class
        Octal      Bytes    Mnemonic  Purpose
        ------    -------   --------  -------
        000000    000 000             Not open
        000400    001 000   E.TENT    Tentative entry, listed as < UNUSED >
        001000    002 000   E.MPTY    Empty file (filename "EMPTY.FIL");
                                      last directory entry, listed as < UNUSED >
        002000    004 000   E.PERM    Permanent file, which is a tentative file
                                      that was closed
        004000    010 000   E.EOS     End of segment marker; can be the
                                      last word of a directory segment,
                                      not followed by name, file type, etc.
        040000    100 000   E.READ    Read-only, protected by monitor from
                                      .WRITE requests
        100000    200 000   E.PROT    Protected permanent file;
                                      only a permanent file can be protected;
                                      a protected file can be modified, just
                                      not deleted

         The File Class field in the lower byte indentifies characteristics
         or group membership of a file.  Only one bit is currently used:
         the Prefix Block bit, which is octal 020.  This bit indicates that
         the file contains at least one prefix block.

      fname1, fname2, and ext are the Radix-50 encoding of a 6-character
      file name and its 3-character extension.

      nblocks is the number of 512(decimal) / 01000(octal) byte blocks
      that the file occupies.  Files are stored contiguously in RT-11
      version 4, the format that this software was developed with.

      job_channel contains the channel number (low byte in word) and
      sometimes the job number (high byte in word) of a file (if associated
      with a job, depending on the RT-11 monitor).  This is only used for
      tentative files.

      creation_date is stored as (RT-11 YEAR is the calendar year minus 1972):

         15   14 13 12   11 10 9   8  7  6   5  4  3   2  1  0
        +--+ +--------+ +-------+ +-------+ +-------+ +-------+
        | A| | A  M  M| | M  M D| |D  D  D| |D  Y  Y| |Y  Y  Y|   Default
        +--+ +--------+ +-------+ +-------+ +-------+ +-------+   -------
          0    0  0  0    0  1 1   0  1  0   1  0  1   0  0  0    (Binary)

          0       0          3        2         5         0       (Octal)

         Bit names are:
            A = Age; multiply by 32 and add to Year field
            M = Month
            D = Day
            Y = Year

         The default creation date for FIG Forth files is marked as
         octal 003250 (binary 0 000 011 010 101 000), corresponding
         to 21-Jan-1980.  That was the release date of FIG Forth 1.3.

         Bits 15 and 14 are only supported by RT-11 version 4 that has
         a Y2K patch, and by later versions of RT-11.  Earlier versions
         of RT-11 cannot handle later dates.

   The file " EMPTY.FIL" is a special placeholder file that appears
   as the last file entry in a directory segment.  Its properties are:

                        Octal
                        -----
      file entry type = 01000 (empty file)
      status          =     0 (not open)
      creation date   =     0

   Following the directory entry for " EMPTY.FIL", the final entry in
   a segment has "entry type" of 04000 (octal), signifying the end
   of the directory segment.  All other fields in this final entry
   in a segment are set to 0.

   All following directory entries (which are therefore unused)
   have all fields set to 0.

   The starting block of a file is the first block after all preceding
   permanent, tentative, and empty directory entries.

   When a directory segment is full and file entries must be created in
   the following segment, approximately half of the file entries in the
   current segment are moved to the next segment.
*/
struct RT11_DIR_ENTRY {
   uint16_t status;
   uint16_t fname1, fname2, fext; /* Radix-50 Filename and Extension       */
   uint16_t nblocks;              /* file length in 512-byte blocks        */
   uint16_t job_channel;          /* job and channel # of a tentative file */
   uint16_t creation_date;
};

