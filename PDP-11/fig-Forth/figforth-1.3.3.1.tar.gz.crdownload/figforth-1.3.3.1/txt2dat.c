/*
   txt2dat - convert newline-terminated lines to
   FORTH.DAT screens of 64 characters per line.
   The dat2txt program performs the conversion
   in the opposite direction.

   Author: Paul Hardy

   This program is in the public domain.
*/

#include <stdio.h>
#include <stdlib.h>


int main () {
   int i;       /* loop variable   */
   char templine [128];  /* input buffer */
   
   i = 0;
   while (fgets (templine, sizeof (char) * 128, stdin) != NULL) {
      for (i = 0; i < 64 && templine [i] != '\n'; i++) {
         putchar (templine [i] & 0xFF);
      }
      while (i++ < 64) putchar (' ');
   }

   exit (EXIT_SUCCESS);
}
